// const express = require('express');
// const app = express();


// // Import routes
// const postRoute = require('./routes/Post');


// //Router MIddlewares
// app.use(express.json());
// app.use('/posts', postRoute);

// module.exports = app;

