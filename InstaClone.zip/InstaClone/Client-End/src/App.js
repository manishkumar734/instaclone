import './App.css';
import LandingPage from './components/landing-page';
// import reportWebVitals from './reportWebVitals';


function App() {
  return (
    <div className="App">
      <h3>InstaClone</h3>
      <LandingPage/>
      {/* <Header/>
      <Postview/> */}
    </div>
  );
}

export default App;
